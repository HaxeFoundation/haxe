#!/bin/sh
rm -rf /usr/lib/haxe/std
rm -rf /usr/lib/haxe/doc