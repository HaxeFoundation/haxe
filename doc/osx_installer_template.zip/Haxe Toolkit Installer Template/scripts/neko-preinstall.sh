#!/bin/sh
rm -rf /usr/lib/neko
