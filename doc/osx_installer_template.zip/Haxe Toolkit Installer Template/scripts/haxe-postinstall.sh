#!/bin/sh
rm /usr/bin/haxe
rm /usr/bin/haxedoc
rm /usr/bin/haxelib
ln -s /usr/lib/haxe/haxe /usr/bin/haxe
ln -s /usr/lib/haxe/haxedoc /usr/bin/haxedoc
ln -s /usr/lib/haxe/haxelib /usr/bin/haxelib
if [ -d "/usr/lib/haxe/lib" ]; then
  mv /usr/lib/haxe/lib-client/* /usr/lib/haxe/lib/
  rm -rf /usr/lib/haxe/lib-client
else
  mv /usr/lib/haxe/lib-client /usr/lib/haxe/lib
fi
chmod -Rf 777 /usr/lib/haxe/lib